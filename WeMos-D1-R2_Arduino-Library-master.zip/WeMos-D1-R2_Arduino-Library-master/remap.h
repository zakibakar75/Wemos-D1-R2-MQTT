/*************************************************
 * Public Constants
 *************************************************/

#define D0  3
#define D1  1

#define D2  16
#define D3  5
#define D4  4

#define D5  D5
#define D6  D6
#define D7  D7
#define D8  0
#define D9  2
#define D10 15

#define D11 13

#define D12  12
#define D13  14
#define D14  *
#define D15  *
